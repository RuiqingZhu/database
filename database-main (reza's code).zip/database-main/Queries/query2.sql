CREATE DATABASE school;
USE school;

CREATE TABLE TEACHERS
(
	id bigint primary key NOT NULL AUTO_INCREMENT,
	first_name VARCHAR(50),
	last_name VARCHAR(50),
	school VARCHAR(50),
	hire_date DATE,
	salary DECIMAL(5,2)
);

-- DROP TABLE teachers; CTRL + /
-- Adding primary key


-- INSERT some values
INSERT INTO TEACHERS(first_name, last_name, school, hire_date, salary)
VALUES('Janet', 'Smith', 'Harward', '2011-10-13', 340.20);

INSERT INTO TEACHERS(first_name, last_name, school, hire_date, salary)
VALUES
('Lee', 'Reynolds', 'F.D. Roosevelt HS', '1993-05-22', 650),
('Samuel', 'Cole', 'Myers Middle School', '2005-08-01', 435),
('Samantha', 'Bush', 'Myers Middle School', '2011-10-30', 362),
('Betty', 'Diaz', 'Myers Middle School', '2005-08-30', 435),
('Kathleen', 'Roush', 'F.D. Roosevelt HS', '2010-10-22', 385);

SELECT * FROM TEACHERS
WHERE id = 2;
