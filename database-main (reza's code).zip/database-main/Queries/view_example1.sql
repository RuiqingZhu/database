 -- 1 -Create a view name it as orderedExpired which is the orders that the shipping dates are older than 80 days
 CREATE VIEW orderedExpired
 AS
 SELECT *
 FROM ORDERS
 -- WHERE (CURDATE() - shippedDate ) > 80;
 WHERE DATEDIFF(CURDATE() , shippedDate ) > 80;
 -- olderthan 80 days -> the shipping date - current date > 80

-- Since I already had created the view, I had to aLTer it 
-- YOu could drop the view and create it again.
ALTER 
VIEW orderedExpired AS
    SELECT *
 FROM ORDERS
 -- WHERE (CURDATE() - shippedDate ) > 80;
 WHERE DATEDIFF(CURDATE() , shippedDate ) > 80;

 -- 2 - Create  a view name it as MontrealCustomers which is the customers that live in canada and city 'Montreal'
 CREATE VIEW montreal_customers
 AS 
 SELECT customerName, postalCode
 FROM customers
 WHERE country = 'Canada' and city = 'Montreal';
 -- 3 - Create the report that shows the emplyoee that work in USA -> it needs join the table office and employee
 CREATE VIEW employee_USA_workers
 AS
 SELECT emp.firstName, emp.lastName, emp.employeeNumber, offices.country, emp.officeCode
 FROM employees emp
 INNER JOIN offices
 ON offices.officeCode = emp.officeCode
 and offices.country = 'USA';

-- 4- Create a view that shows the payments for customers who doesn't have telephone number
CREATE VIEW payment_no_phone
AS
SELECT p.customerNumber, cus.contactFirstName, cus.contactLastName
FROM payments p 
INNER JOIN customers cus
ON p.customerNumber = cus.customerNumber
AND cus.phone IS NULL;


-- SELECT o.officeCode, emp.firstName, emp.lastName, o.city, o.phone office_phone_number from offices o
-- INNER JOIN employees emp
-- USING (officeCode);  -- less flexible
-- -- USING requires the names of the columns in both tables to be identical:


-- SELECT  o.officeCode, emp.firstName, emp.lastName, o.city, o.phone office_phone_number
-- FROM offices o
-- JOIN employees emp
-- ON emp.officeCode = o.officeCode
