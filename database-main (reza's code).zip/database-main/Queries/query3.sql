use classicmodels;

-- WHERE
SELECT * from customers
WHERE customerName = 'Atelier graphique'; 

SELECT * from customers
WHERE salesRepEmployeeNumber = 1504;

SELECT * from employees
WHERE employeeNumber = 1504;

SELECT * from customers
WHERE creditLimit > 81700.00;

SELECT * from customers
WHERE country = 'USA';

-- the customers who are not in USA
SELECT * from customers
WHERE country != 'USA';
SELECT * from customers
WHERE country <> 'USA';


-- write a query to give me the customers in City Nantes
SELECT * FROM customers
WHERE city = 'Nantes';


-- using between for a range of data ( date, int, double, ...)
SELECT * from orders ord
where ord.orderDate BETWEEN '2003-01-01' and '2003-01-11';


-- SELECT * FROM customers
-- WHERE country = 'France' or country = 'Singapore' or country = 'USA'

SELECT * FROM customers
WHERE country in ('France', 'Singapore', 'USA');


 -- Sort the data if you don't provide it will be ascending
SELECT * FROM
CUSTOMERS
ORDER BY customerName;

-- descnding if you mention
SELECT * FROM
CUSTOMERS
ORDER BY customerName DESC;


-- sorting based on different criteria
SELECT * FROM
CUSTOMERS
ORDER BY country, state, city;


-- DISTICT -> helps me to have the data that is repeated only one time
select DISTINCT(country) from CUSTOMERS
order by country;

-- IS NULL
SELECT * FROM customers
where addressLine2 is NOT NULL


-- String functions

SELECT 	('JOHNABBOTT');

SELECT customerName, CHAR_LENGTH(customerName) FROM 
CUSTOMERS;

SELECT customerName, addressLine1, addressLine2,  concat(COALESCE(addressLine1, ''), ' ' , COALESCE(addressLine2, '')) full_address FROM 
CUSTOMERS;

-- LIKE
SELECT * from customers
where addressLine1 LIKE '%ehmen%';

-- NOT LIKE
SELECT * from customers
where addressLine1 NOT LIKE '%ehmen%';

-- LOWER
SELECT LOWER(customerName) from customers
where addressLine1 LIKE '%ehmen%';

 -- REPLACE(str,from_str,to_str)

SELECT REPLACE(city,'New', 'OLD') from customers



-- Distinct

-- order by


 -- the count of all the orders that are between a certain time
 
 use classicmodels;
 
  SELECT * from orders ord
where ord.orderDate BETWEEN '2003-01-01' and '2003-01-11';

 -- COUNT is an aggregate function
 SELECT COUNT(*) from orders ord
where ord.orderDate BETWEEN '2003-01-01' and '2003-01-11';

 -- Count of orders based on a status
 SELECT COUNT(*), status from orders
 WHERE orderDate BETWEEN '2002-01-01' and '2003-12-11'
 GROUP BY status;
 
-- Sum of all the payments for all the customers
 -- DESCRIBE payments;

SELECT customerNumber, SUM(amount) sum_payments, AVG(amount) ava_amount,  COUNT(*) count_payments  from payments
group by customerNumber;
-- Sum of all the payments for each customer
 
SELECT MAX(amount) max_amount, MIN(amount) min_amount, customerNumber
 FROM payments
 GROUP BY customerNumber;

-- to see the list of payments and having the provincal tax as a new column
SELECT 
customerNumber, paymentDate, amount,
(amount * 1.5 / 100) AS provincal_tax ,-- you can add a new column in your SELECT
(amount * 1.5 / 100) * 2 AS total_tax 
from payments;

 
 
 