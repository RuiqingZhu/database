-- It gives me ALL the customer with/without order
SELECT 
    customers.customerNumber, 
    customerName, 
    orderNumber, 
    status
FROM
    customers
LEFT JOIN orders ON 
    orders.customerNumber = customers.customerNumber
ORDER by orderNumber;
-- 353 record -> left 
-- 353 = 329 + 24

-- customers with order
SELECT 
    customers.customerNumber, 
    customerName, 
    orderNumber, 
    status
FROM
    customers
INNER JOIN orders ON 
    orders.customerNumber = customers.customerNumber
ORDER by orderNumber;
-- 329 record 


SELECT *
FROM 
customers
where customerNumber NOT IN (SELECT customerNumber from orders);
-- 24 record

-- SELECT *
-- FROM 
-- customers
-- where customerNumber  IN (SELECT customerNumber from orders)
-- -- 98 record

