use classicmodels;

 -- DROP PROCEDURE sp_test1; -> dropping a stored procedure
DELIMITER $$

CREATE PROCEDURE sp_test1()
BEGIN
-- body of your sp
END $$

DELIMITER ;



DELIMITER $$

CREATE PROCEDURE GetCustomers()
BEGIN
  SELECT * FROM customers;
END$$

DELIMITER ;

CALL GetCustomers();
-- Add parameter to the method

-- IN
-- OUT
-- INOUT

DELIMITER $$
CREATE PROCEDURE GetCustomers2(IN p_phone_number VARCHAR(11))
BEGIN
  SELECT * FROM customers
  WHERE phone = p_phone_number;
END$$

DELIMITER ;

CALL GetCustomers2('7025551838');


DELIMITER $$
CREATE PROCEDURE GetCustomers3(IN p_phone_number VARCHAR(11), OUT customerId INT)
BEGIN
  SELECT customerNumber INTO customerId
  FROM customers
  WHERE phone = p_phone_number;
END$$

DELIMITER ;

CALL GetCustomers3('7025551838', @cid);
SELECT @cid;

DELIMITER $$
CREATE PROCEDURE GetCustomers4(IN p_phone_number VARCHAR(11), OUT customerId INT)
BEGIN
  SELECT customerNumber INTO customerId
  FROM customers;
  -- WHERE phone = p_phone_number;
END$$

DELIMITER ;

CALL GetCustomers4('7025551838', @cid);
SELECT @cid;

DROP PROCEDURE INOUT_example;
DELIMITER $$
CREATE PROCEDURE INOUT_example(OUT ver_param VARCHAR(25), INOUT incr_param INT)
BEGIN
  # SET a value for out parameter
  SELECT VERSION() INTO ver_param;
  # Increment value of inout parameter
  SET incr_param = incr_param + 1;
END$$

DELIMITER ;

SET @increment = 10;
CALL INOUT_example(@version_result, @increment);
SELECT @version_result, @increment 



------

 -- DECLARE <variable_name> datatype(size) [default default_value]
 -- DECLARE totalSale DEC(10,2) DEFAULT 0.0
 -- DECLARE x,y INT default 0;
 
 
 -- SET A value
 -- SET variable_name = value

DROP PROCEDURE GetTotalOrders;

DELIMITER $$

CREATE PROCEDURE GetTotalOrders()
BEGIN
	
    #declaretion
    DECLARE totalOrder1 INT default 0;
	DECLARE totalOrder2 INT default 0;
    
    # body
    SELECT COUNT(*)
    INTO totalOrder1
    FROM orders;
    
	SELECT COUNT(*)
    INTO totalOrder2
    FROM orders;
    
    # return
    SELECT totalOrder1, totalOrder2;
END$$

DELIMITER ;

CALL GetTotalOrders();

--
SHOW PROCEDURE STATUS
WHERE definer = 'root@localhost'
AND Db = 'classicmodels'

-- IF statement

-- IF condition THEN
-- STATMENT
-- END IF;
DELIMITER $$
CREATE PROCEDURE GetCustomerType(IN pCustomerNumber INT)
BEGIN
  
  #declaration
  DECLARE credit DECIMAL(10,2) DEFAULT 0;
  DECLARE customerLevel VARCHAR(20);
  
  
  SELECT creditLimit
  INTO credit
  FROM customers
  WHERE customerNumber = pCustomerNumber; 
  
  -- ADD logic
  IF credit > 50000 THEN
    SET customerLevel = 'PLATINIUM';
  ELSE
    SET customerLevel = 'SILVER';

  END IF;
  
  SELECT customerLevel;
END$$
DELIMITER ;

CALL GetCustomerType(131);

-- check phone
DELIMITER $$
CREATE PROCEDURE CheckPhone(IN p_name VARCHAR(20), OUT city VARCHAR(20))
BEGIN
	-- Define
    DECLARE pre_number VARCHAR(3);
    
    -- SET the value
    SELECT SUBSTRING(phone, 1, 3)
    INTO pre_number
    FROM customers
    WHERE contactFirstName = p_name;
    
    -- Processing the phone number of a person
    IF pre_number = '438' OR pre_number = '514' THEN
		SET city = 'Montreal';
	END IF;
END$$    
 DELIMITER ;   
 
 CALL CheckPhone('Pirkko', @cityName);
 SELECT  @cityName
 
 
 -- check phone
DELIMITER $$
CREATE PROCEDURE CheckPhone2(IN p_name VARCHAR(20))
BEGIN
	-- Define
    DECLARE pre_number VARCHAR(3);
    DECLARE cityName VARCHAR(30);
    
    -- SET the value
    SELECT SUBSTRING(phone, 1, 3)
    INTO pre_number
    FROM customers
    WHERE contactFirstName = p_name;
    
    -- Processing the phone number of a person
    IF pre_number = '438' OR pre_number = '514' THEN
		SET cityName = 'Montreal';
	END IF;
    
    SELECT cityName;
END$$    
 DELIMITER ;   
 
 CALL CheckPhone2('Pirkko');
 
 
 -- LOOP
 -- [LABLE] : LOOP
 
-- END LOOP;
DELIMITER $$
CREATE PROCEDURE LoopDemo()
BEGIN
  DECLARE x INT;
  DECLARE str VARCHAR(255);
  
  SET x = 1;
  SET str = '';
  
  loop_lable : LOOP
	IF x > 10 THEN
		LEAVE loop_lable;
    END IF;
    
    SET x = x + 1;
    IF (x mod 2) THEN
		ITERATE loop_lable; -- continue 
	ELSE
		SET str = CONCAT(str, x, ',');
    END IF;	
  END LOOP;
  
  SELECT str;
  
END$$
DELIMITER ;

CALL LoopDemo();

 -----
 
 
 DELIMITER $$
CREATE PROCEDURE createEmailList(INOUT emailList Varchar(4000))
BEGIN
  DECLARE finished INT DEFAULT 0;
  DECLARE emailAddress varchar(100) DEFAULT "";
  
  -- declare cursor for employee email
  DECLARE curEmail CURSOR FOR
  SELECT email
  FROM employees;
  
  -- declare NOT FOUND handler
   DECLARE CONTINUE HANDLER
   FOR NOT FOUND SET finished = 1;
   
   OPEN curEmail;
   
   getEmail: LOOP
	FETCH curEmail INTO emailAddress;
    IF finished = 1 THEN
		LEAVE getEmail;
	END IF;
    
    SET emailList = CONCAT(emailAddress, ',', emailList);
    
   END LOOP getEmail;
   CLOSE curEmail;
END $$
DELIMITER ;

SET @emailList = '';
CALL createEmailList(@emailList);
SELECT @emailList;

----

-- Function
DELIMITER $$
CREATE FUNCTION test_function() RETURNS INT
DETERMINISTIC
BEGIN
  RETURN 10000;
END $$

-- DELIMITER ;

-- WE do not have IN/out/INOUT in the functions
SELECT test_function();

DELIMITER $$

CREATE Function getCustomerType(credit DECIMAL(10,2))
RETURNS VARCHAR(20)
DETERMINISTIC 
BEGIN
  DECLARE customerLevel VARCHAR(30);
  
    IF credit > 50000 THEN
		SET customerLevel = 'PLATINUM';
    ELSEIF (credit <= 50000 AND 
			credit >= 10000) THEN
        SET customerLevel = 'GOLD';
    ELSEIF credit < 10000 THEN
        SET customerLevel = 'SILVER';
    END IF;
    
    RETURN (customerLevel);
END $$

DELIMITER ;

SELECT getCustomerType(71800.00)

---
DELIMITER $$
CREATE PROCEDURE GetCustomerTypeWithFunction(IN pCustomerNumber INT, OUT customerLevel VARCHAR(30))
BEGIN
  
  #declaration
  DECLARE credit DECIMAL(10,2) DEFAULT 0;

  SELECT creditLimit
  INTO credit
  FROM customers
  WHERE customerNumber = pCustomerNumber; 
  
  -- ADD logic
   SET customerLevel = getCustomerType(credit);

END$$
DELIMITER ;

DROP PROCEDURE GetCustomerTypeWithFunction;
CALL GetCustomerTypeWithFunction(112, @levelCustomer);
SELECT @levelCustomer;