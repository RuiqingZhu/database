-- create trigger

-- create table audit
CREATE TABLE employees_audit (
    id INT AUTO_INCREMENT PRIMARY KEY,
    employeeNumber INT NOT NULL,
    lastname VARCHAR(50) NOT NULL,
    changedat DATETIME DEFAULT NULL,
    action VARCHAR(50) DEFAULT NULL
);

CREATE TRIGGER before_employee_update
BEFORE UPDATE ON employees
    FOR EACH ROW 
    # what action ?
    INSERT INTO employees_audit
	SET action = 'update',
     employeeNumber = OLD.employeeNumber,
     lastname = OLD.lastname,
     changedat = NOW();
     
SHOW TRIGGERS;
     
UPDATE employees 
SET 
    lastName = 'Phan'
WHERE
    employeeNumber = 1056;
    
SELECT * fROM employees
where  employeeNumber = 1056;

-- DROP
drop trigger if exists before_employee_update;

-- checking integrity
CREATE TABLE billings (
    billingNo INT AUTO_INCREMENT,
    customerNo INT,
    billingDate DATE,
    amount DEC(10 , 2 ),
    PRIMARY KEY (billingNo)
);

DELIMITER $$
CREATE TRIGGER before_billing_update
BEFORE UPDATE 
 ON billings FOR EACH ROW
 BEGIN
	IF NEW.amount > OLD.amount * 10 THEN
		SIGNAL SQLSTATE '45000' 
		SET MESSAGE_TEXT = 'New amount cannot be 10 times greater than the current amount.';
    END IF;
 END $$
 
 SHOW TRIGGERS;
 
 insert into billings(customerNo, billingDate, amount)
 VALUES (1, NOW(), 100);

update billings
set amount = 100000

-- BEFORE INSERT
CREATE TABLE WorkCenters (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    capacity INT NOT NULL
);

CREATE TABLE WorkCenterStats(
    totalCapacity INT NOT NULL
);

DELIMITER $$

CREATE TRIGGER before_workcenters_insert
BEFORE INSERT 
ON WorkCenters
FOR EACH ROW
BEGIN
   DECLARE rowcount INT;
   
   SELECT COUNT(*)
   INTO rowcount
   FROM WorkCenterStats;
   
   IF rowCount > 0 THEN
	UPDATE WorkCenters
    SET totalCapacity = totalCapacity + NEW.capacity;
   ELSE
    INSERT INTO WorkCenterStats(totalCapacity)
    VALUES (NEW.capacity);
   END IF;
   
   
END$$


-- Create a table name as messages
-- after each customer insertion
-- send a message to the phone number of that customer
-- table messages
 -- phone_number 
 -- message
 -- send_date
 -- provider
 -- you need to insert a record into table messages
 -- after updating a record in the table customer
 -- update the table messages
  -- so we need 2 triggers