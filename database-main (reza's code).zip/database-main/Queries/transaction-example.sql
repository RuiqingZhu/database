-- 1. start a new transaction
set autocommit = 0;
START TRANSACTION;

-- 2. Get the latest order number
SELECT 
    @orderNumber:=MAX(orderNUmber)+1
FROM
    orders;
    
INSERT INTO orders(orderNumber,
                   orderDate,
                   requiredDate,
                   shippedDate,
                   status,
                   customerNumber)
VALUES(@orderNumber,
       '2005-05-31',
       '2005-06-10',
       '2005-06-11',
       'In Process',
        145);
        
        
-- 4. Insert order line items
INSERT INTO orderdetails(orderNumber,
                         productCode,
                         quantityOrdered,
                         priceEach,
                         orderLineNumber)
VALUES(@orderNumber,'S18_1749', 30, '136', 1),
      (@orderNumber,'S18_2248', 50, '55.09', 2); 
      
-- 5. commit changes    
COMMIT;


SELECT 
    a.orderNumber,
    orderDate,
    requiredDate,
    shippedDate,
    status,
    comments,
    customerNumber,
    orderLineNumber,
    productCode,
    quantityOrdered,
    priceEach
FROM
    orders a
        INNER JOIN
    orderdetails b USING (orderNumber)
WHERE
    a.ordernumber = @orderNumber;
	
	
	
	------
	
	
	 set autocommit= 0;
 SET SQL_SAFE_UPDATES = 0;

 START TRANSACTION;
  DELETE FROM orderdetails;
  SELECT * FROM orderdetails;
  
  rollback; -- if you are in a transaction by using rollback you can come back whatever you did
  
  
  use session7;

SET autocommit=0;
CREATE TABLE EMP(
   FIRST_NAME CHAR(20) NOT NULL,
   LAST_NAME CHAR(20),
   AGE INT,
   SEX CHAR(1),
   INCOME FLOAT);
   
   INSERT INTO EMP VALUES
   ('Krishna', 'Sharma', 19, 'M', 2000),
   ('Raj', 'Kandukuri', 20, 'M', 7000),
   ('Ramya', 'Ramapriya', 25, 'F', 5000);
   
START TRANSACTION;
SELECT * FROM EMP;
UPDATE EMP SET AGE = AGE + 1;

SAVEPOINT samplesavepoint;
INSERT INTO EMP VALUES  ('Mac', 'Mohan', 26, 'M', 2000);

ROLLBACK TO  samplesavepoint;
COMMIT;

delete from EMP
where first_name = 'Mac';






-- you write sql script 
-- throw an exception ROLLBACK 
