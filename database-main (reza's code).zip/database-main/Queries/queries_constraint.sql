create database session4;
use session4;

drop table students;
create table students(
	id BIGINT AUTO_INCREMENT PRIMARY KEY,
    student_number VARCHAR(30) UNIQUE,
	first_name VARCHAR(30),
	last_name VARCHAR(30),
	gender ENUM('M','F'),
	phone_number VARCHAR(11) UNIQUE
);

 -- GUID
 
 DESCRIBE students;
 -- Register a student information but havent' generate any student ID 
 INSERT INTO students(student_number, first_name, last_name)
 VALUES (NULL, 'reza', 'shalchian');
 
  INSERT INTO students(student_number, first_name, last_name)
 VALUES (NULL, 'BETTY', 'MAXIM');
 
   INSERT INTO students(student_number, first_name, last_name)
 VALUES ('111', 'JUDI', 'MAXIM');
 
    INSERT INTO students(student_number, first_name, last_name)
 VALUES ('111', 'JIL' , 'VALENTINE');
 
 SELECT * From students;
 
-- ALTER TABLE student
-- RENAME TO students; -- NO QUOTATION

-- UNIQUE constraint accepts NULL and PK does not accept
-- You can have multiple UNIQUE KEYs but you can have only 1 Primary key


CREATE TABLE parent (
    id INT NOT NULL,
    PRIMARY KEY (id)
);

CREATE TABLE child (
    id INT,
    parent_id INT,
--    INDEX par_ind (parent_id), it is good to have an index on the foreign key to have better SELECT performance
    FOREIGN KEY (parent_id)
        REFERENCES parent(id)
        -- ON DELETE CASCADE -> when we delete a parent row, all the children will be deleted cacase
) ;



create table accounts(
 id BIGINT primary key AUTO_INCREMENT,
 customer_id BIGINT,
 FOREIGN KEY(customer_id) REFERENCES  customer(customer_id)
);

create table customer(
	customer_id BIGINT primary key AUTO_INCREMENT,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    telephone_number VARCHAR(10) NOT NULL UNIQUE
);

 -- ALTER TABLE accounts AUTO_INCREMENT = 1; rest the auto_increment


INSERT INTO accounts(customer_id)
VALUES(1);

SELECT * FROM CUSTOMER;
SELECT * FROM accounts;

INSERT INTO customer
(
`first_name`,
`last_name`,
`telephone_number`)
VALUES
(
'a',
'b', '1111');

INSERT INTO customer
(
`first_name`,
`last_name`,
`telephone_number`)
VALUES
(
'c',
'd', NULL);

describe customer;

-- create table customer2(
-- 	customer_id BIGINT AUTO_INCREMENT,
--     first_name VARCHAR(50),
--     last_name VARCHAR(50),
--     telephone_number VARCHAR(10),
-- 	PRIMARY KEY (customer_id, telephone_number) 
-- );

INSERT INTO customer2
(
`first_name`,
`last_name`,
`telephone_number`)
VALUES
(
'a',
'b', '1111');

INSERT INTO customer2
(
`first_name`,
`last_name`,
`telephone_number`)
VALUES
(
'a',
'b', '1111');

select * from customer2;

describe customer2;

-- create table customer3(
-- 	customer_id BIGINT,
--     first_name VARCHAR(50),
--     last_name VARCHAR(50),
--     telephone_number VARCHAR(10),
-- 	PRIMARY KEY (customer_id, telephone_number) 
-- );
-- INSERT INTO customer3
-- (
-- `customer_id`,
-- `first_name`,
-- `last_name`,
-- `telephone_number`)
-- VALUES1
-- (
-- 1,
-- 'a',
-- 'b', '1111');


-- INSERT INTO customer3
-- (
-- `customer_id`,
-- `first_name`,
-- `last_name`,
-- `telephone_number`)
-- VALUES
-- (
-- 1,
-- 'a',
-- 'b', '1111');


CREATE TABLE Persons (
    ID int NOT NULL,
    last_name varchar(255) NOT NULL,
    first_name varchar(255),
    age int,
    city varchar(255),
    CONSTRAINT CHK_Person CHECK (age>=15 AND city='Montreal')
);

describe Persons;

INSERT INTO Persons(ID, last_name, first_name, age, city) 
VALUES (1, 'shal', 'reza', 15, 'Toronto');


create table teacher(
 id int auto_increment primary key,
 name VARCHAR(30),
 college_name VARCHAR(50) default 'Johnabbott'
);

INSERT INTO teacher(name)
VALUES('reza');

select * from teacher;



-- create table accounts(
--  id BIGINT primary key AUTO_INCREMENT,
--  customer_id BIGINT,
--  FOREIGN KEY(customer_id) REFERENCES  customer(customer_id)
-- );

CREATE INDEX idx_customer_id
ON accounts(customer_id);