 -- the count of all the orders that are between a certain time
 
  SELECT * from orders ord
where ord.orderDate BETWEEN '2003-01-01' and '2003-01-11';

 -- COUNT is an aggregate function
 SELECT COUNT(*) from orders ord
where ord.orderDate BETWEEN '2003-01-01' and '2003-01-11';

 -- Count of orders based on a status
 SELECT COUNT(*), status from orders
 WHERE orderDate BETWEEN '2002-01-01' and '2003-12-11'
 GROUP BY status;
 
-- Sum of all the payments for all the customers
DESCRIBE payments;
SELECT customerNumber, SUM(amount) sum_payments, AVG(amount) ava_amount,  COUNT(*) count_payments  from payments
group by customerNumber;
-- Sum of all the payments for each customer
 
 -- MAX and MIN
 -- to know the max payment of each customer
 SELECT MAX(amount), customerNumber
 FROM payments
 GROUP BY customerNumber;