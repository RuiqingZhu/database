SELECT * from customers;
SELECT * from products;
SELECT * from orders;

INSERT INTO products(name, price, coffee_origin)
values ('TOTO', 2.00, 'Sri lanka');

INSERT INTO products(name, price, coffee_origin)
values ('PEPPA', 3.00, 'Colombia');

INSERT INTO orders(product_id, customer_id, order_time)
VALUES (3, 4, '2023-12-01 12:10:11');
INSERT INTO orders(product_id, customer_id, order_time)
VALUES (4, 1, '2023-12-01 12:10:11');
INSERT INTO orders(product_id, customer_id, order_time)
VALUES (1, 5, '2023-12-01 12:10:11');
INSERT INTO orders(product_id, customer_id, order_time)
VALUES (2, 10, '2023-12-01 12:10:11');

INSERT INTO orders(product_id, customer_id, order_time)
VALUES (3, 4, '2023-11-01 12:10:11');
INSERT INTO orders(product_id, customer_id, order_time)
VALUES (4, 1, '2023-10-01 12:10:11');
INSERT INTO orders(product_id, customer_id, order_time)
VALUES (1, 5, '2023-09-01 12:10:11');
INSERT INTO orders(product_id, customer_id, order_time)
VALUES (2, 10, '2021-11-01 12:10:11');
INSERT INTO orders(product_id, customer_id, order_time)
VALUES (6, 11, '2021-11-01 12:10:11');
INSERT INTO orders(product_id, customer_id, order_time)
VALUES (4, 11, '2021-11-01 12:10:11');
INSERT INTO orders(product_id, customer_id, order_time)
VALUES (4, 1, '2021-11-01 12:10:11');


 -- From the customers table, select the first name and phone number of all the females who have a last name of Bluth
SELECT first_name, phone_number
FROM customers
WHERE gender = 'F' and last_name = 'Bluth';

 -- From the products table, select the name for all products that have a price greater than 3.00 or a coffee origin of Sri Lanka.
SELECT *
FROM products
WHERE price > 3.00 OR coffee_origin = 'Sri Lanka';


-- How many male customers don’t have a phone number entered into the customers table?
SELECT COUNT(*) male_without_phone_customer_count
FROM customers
WHERE phone_number IS NULL and gender = 'M';

-- From the products table, select the name and price of all products with a coffee origin
-- equal to Colombia or Indonesia. Ordered by name from A-Z.
SELECT name, price, coffee_origin
FROM products
where coffee_origin IN ('Colombia', 'Indonesia')
ORDER BY name;

-- From the orders table, select all the orders from February 2017 for customers with id’s of 2, 4, 6 or 8. 
SELECT * 
FROM orders
WHERE order_time >= '2017-02-01' and id IN(2, 4, 6, 8);

-- From the customers table, select the first name and phone number of all customers who’s last name contains the pattern ‘ar’.
SELECT first_name, phone_number
FROM customers
WHERE last_name LIKE '%ar%';

-- From the customers table, select distinct last names and order alphabetically from A-Z. 
SELECT DISTINCT last_name
FROM customers
ORDER BY last_name;
-- From the orders table, select the first 3 orders placed by customer with id 1, in February 2017.
SELECT *
FROM orders
WHERE order_time LIKE '2021-02%'
-- SUB QUERY
-- AND customer_id IN (SELECT id from customers where id = 1)
AND customer_id = 1
ORDER BY order_time
LIMIT 3;

-- From the products table, select the name, price and coffee origin but rename the price to  retail_price in the results set.
SELECT name, price AS retail_price, coffee_origin
FROM products
