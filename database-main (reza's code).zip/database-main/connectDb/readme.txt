https://www.vogella.com/tutorials/MySQLJava/article.html

https://dev.mysql.com/downloads/connector/j/?os=26